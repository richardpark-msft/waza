result = [x**2 for x in range(20) if x % 3 == 0]
